const express = require("express");
const cors = require("cors");
require("dotenv").config();

const authRoutes = require("./routes/authRoutes");
const passengerRoutes = require("./routes/passengerRoutes");
const riderRoutes = require("./routes/riderRoutes");

const app = express();

const PORT = 5000;

// =========================
// MIDDLEWARE
// =========================

app.use(cors());

app.use(express.json());

// Log every incoming request
app.use((req, res, next) => {
  console.log("=================================");
  console.log("REQUEST:", req.method, req.originalUrl);
  console.log("BODY:", req.body);
  console.log("=================================");

  next();
});

// =========================
// TEST ROUTE
// =========================

app.get("/", (req, res) => {
  res.status(200).send("Smart Ride Backend Server is Running!");
});

// =========================
// API ROUTES
// =========================

app.use("/api/auth", authRoutes);
app.use("/api/rides", passengerRoutes);
app.use("/api/rider", riderRoutes);

// =========================
// 404 ROUTE
// =========================

app.use((req, res) => {
  console.log("404 ROUTE:", req.method, req.originalUrl);

  res.status(404).json({
    message: "Route not found",
    path: req.originalUrl,
  });
});

// =========================
// ERROR HANDLER
// =========================

app.use((err, req, res, next) => {
  console.error("SERVER ERROR:", err);

  res.status(500).json({
    message: "Internal server error",
    error: err.message,
  });
});

// =========================
// START SERVER
// =========================

app.listen(PORT, () => {
  console.log(`Server is happily running on port ${PORT}`);
  console.log(`Backend URL: http://localhost:${PORT}`);
});